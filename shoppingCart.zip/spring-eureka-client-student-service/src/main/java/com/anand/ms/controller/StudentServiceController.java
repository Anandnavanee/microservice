package com.anand.ms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anand.ms.model.Student;

@RestController
public class StudentServiceController {

	private static Map<String,List<Student>>   schoolDB = new HashMap<String,List<Student>>();
	static {
		schoolDB = new HashMap<String,List<Student>>();
		List<Student> list = new ArrayList<Student>();
		Student std = new Student("Ankur","class v");
		list.add(std);
		std = new Student("bharat","class VI");
		list.add(std);
		
		schoolDB.put("abcSchool", list);
		
		list = new ArrayList<Student>();
	    std = new Student("Anang","class v");
		list.add(std);
		std = new Student("siranjeev","class VI");
		list.add(std);
		
		schoolDB.put("xyzSchool", list);
		
	}

	
	@RequestMapping(value="/getStudentDetailsForSchool/{schoolname}",method=RequestMethod.GET)
	public List<Student> getStudents(@PathVariable String schoolname){
		System.out.println("Getting student details for "+schoolname);
		List<Student> studentlist = schoolDB.get(schoolname);
		if(studentlist == null) {
			studentlist = new ArrayList<Student>();
			Student std = new Student("Not Found","N/A");
			studentlist.add(std);
		}
		return studentlist;
	}


}
